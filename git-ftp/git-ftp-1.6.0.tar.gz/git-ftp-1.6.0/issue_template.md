### Bug / Enhancement / Question ?

* How to reproduce the issue?
* Can you point to a Git repository to reproduce it?
* Or can you describe the directory structure?

### Environment

Please copy the output of the following commands.

```sh
echo "$SHELL"
uname -a
git-ftp version
```
